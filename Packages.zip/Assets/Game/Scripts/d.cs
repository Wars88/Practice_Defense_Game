﻿using UnityEngine;
using UnityEngine.Events;

public class Bbutton : MonoBehaviour
{

    protected virtual void Awake()
    {
        var button = GetComponent<UnityEngine.UI.Button>();
    }


}