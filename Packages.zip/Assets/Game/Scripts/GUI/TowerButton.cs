﻿using UnityEngine;

public class TowerButton : MonoBehaviour
{     
    public GameObject towerPrefab; // 유니티에서 할당하려면 안만들어도 됨. 인풋매니저에서 클릭 이벤트처리해서.

}
